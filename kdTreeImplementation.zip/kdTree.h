#pragma once
#include "Triangle.h"
#include "Box.h"
#include "splitPlane.h"

struct kdTreeNode
{
	kdTreeNode * left;
	kdTreeNode * right;
	bool isLeaf = false;
	std::vector<Triangle *> triangles;
	kdTreeNode(kdTreeNode * left, kdTreeNode * right, bool isLeaf) : left(left), right(right), isLeaf(isLeaf) {}
	kdTreeNode(kdTreeNode * left, kdTreeNode * right, bool isLeaf, std::vector<Triangle *> triangles) : left(left), right(right), isLeaf(isLeaf), triangles(triangles) {}
};

class SAHkdTree
{
	//KT and KI
	float KT;
	float KI;
	Box boundingBox;
	enum Side {Left, Right, Unknown};

	private:
	float lambda(int NL, int NR) const
	{
		return (NL == 0 || NR == 0) ? 0.8f : 1.0f;	
	}

	float splitScore(float probLeft, float probRight, int NL, int NR) const
	{
		return lambda(NL, NR) * (KT + KI * (probLeft * NL + probRight * NR));
	}	

	float PVsubGivenV(const Box & vSub, const Box & V)
	{
		return vSub.surfaceArea() / V.surfaceArea();
	}

	void splitBox(splitPlane & p, Box & V, Box & VL, Box & VR)
	{
		VL = V;
		VR = V;
		VL.setMax(p.pk, p.pe);
		VR.setMin(p.pk, p.pe);
	}

	void SAH(splitPlane & p, Box V, int NL,int NP,  int NR, float & C, Side & pSide)
	{
		Box VL, VR;
		splitBox(p, V, VL, VR);	
		float pL = PVsubGivenV(VL, V);
		float pR = PVsubGivenV(VR, V);
		float CPL = splitScore(pL, pR, NL + NP, NR);
		float CPR = splitScore(pL, pR, NL, NR + NP);
		if (CPL < CPR)
		{
			pSide = Left;
			C = CPL;
		}
		else
		{
			pSide = Right;
			C = CPR;
		}
	}

	struct Event
	{
		enum EventType {startingOnPlane=2, lyingOnPlane=1, endingOnPlane = 0};
		Triangle * t;
		splitPlane p;
		EventType type;
		Event(Triange * t, int k, float 
	};

	Box clipTriangleToBox(Triange * t, const Box & V)
	{
		Box tB = t->getBoundingBox();
		for (int i = 0; i < 3; ++i)
		{	
			
		}

		return tB;
	}

	public:

	kdTreeNode * buildTree(std::vector<Triangle *> T, Box &V)
	{
		return nullptr;
	}
};
