#pragma once

class Box
{
	public:
		Vec lowerLeft;
		Vec topRight;

		Box(){}
		Box(Vec lowerLeft, Vec topRight) : lowerLeft(lowerLeft), topRight(topRight) {}
		Box(const Box & second) : lowerLeft(second.lowerLeft), topRight(second.topRight) {}
		
		Box & operator=(const Box & second)
		{
			lowerLeft = second.lowerLeft;
			topRight = second.topRight;
			return *this;
		}

		float surfaceArea() const
		{
			float dx = abs(lowerLeft.x - topRight.x);	
			float dy = abs(lowerLeft.y - topRight.y);
			float dz = abs(lowerLeft.z - topRight.z);
			return 2 * dx * dy + 2 * dx * dz + 2 * dy * dz;
		}

		void setMin(int pk, float pe)
		{
			if (pk == 0)
				lowerLeft.x = pe;
			else if (pk == 1)
				lowerLeft.y = pe;
			else if (pk == 2)
				lowerLeft.y = pe;
		}

		void setMax(int pk, float pe)
		{
			if (pk == 0)
				topRight.x = pe;				
			else if (pk == 1)
				topRight.y = pe;
			else if (pk == 2)
				topRight.z = pe;
		}
};
