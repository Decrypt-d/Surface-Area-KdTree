
class splitPlane
{
	public:
		int pk;		
		float pe;
		splitPlane(int pk, float pe) : pe(pe), pk(pk){}
};
