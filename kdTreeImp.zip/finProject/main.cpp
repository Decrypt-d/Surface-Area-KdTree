#include "objParser.h"
#include "model.h"

int main()
{
	model test;
	objParser::parseObjFile("bunny.obj", test);
	test.printMesh();
}
