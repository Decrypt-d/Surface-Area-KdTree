#pragma once
#include "Triangle.h"
#include <vector> 
#include "kdTree.h"

class model : public Geometry
{
	public:
	std::vector<Triangle> triangleMesh;
	
	void printMesh()
	{
		for (int i = 0; i < triangleMesh.size(); ++i)
		{
			std::cout << "v1: [ " << triangleMesh[i].v1.x <<  " " << triangleMesh[i].v1.y << " " << triangleMesh[i].v1.z << " ]  ";
			std::cout << "v2: [ " << triangleMesh[i].v2.x <<  " " << triangleMesh[i].v2.y << " " << triangleMesh[i].v2.z << " ]  ";
			std::cout << "v3: [ " << triangleMesh[i].v3.x <<  " " << triangleMesh[i].v3.y << " " << triangleMesh[i].v3.z << " ]";
			std::cout << std::endl;
		}
	}
	



    virtual bool intersect(const Vec& p, const Vec& i, Vec& np, Vec& n) const
	{
		return false;
	}

    virtual Vec samplePoint(float& pdf) const
	{

		return Vec();
	}

    //virtual bool boundingBoxCheck(const Vec& p, const Vec& i) =0;
};
